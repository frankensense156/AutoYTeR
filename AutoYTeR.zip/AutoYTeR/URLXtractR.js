(async function() {
  // --- 1. Singleton Lock (Prevents double-running) ---
  if (window.piepImportRunning) {
      // If already running, just focus on the existing process
      console.log("PIEP is already running.");
      return;
  }
  window.piepImportRunning = true;
  let isRunning = true;

  // --- Helpers ---
  const delay = (ms) => new Promise(res => setTimeout(res, ms));

  /**
   * Waits for an element to exist.
   * If 'isRunning' becomes false, it rejects with "Stopped" immediately.
   */
  function waitForElement(selector, text = null, timeout = 10000) {
      return new Promise((resolve, reject) => {
          const start = Date.now();
          const check = setInterval(() => {
              // IMMEDIATE STOP CHECK
              if (!isRunning) { 
                  clearInterval(check); 
                  reject("Stopped"); // Throw specific stop signal
                  return; 
              }
              
              const elements = document.querySelectorAll(selector);
              let found = null;

              if (text) {
                  for (let el of elements) {
                      if (el.innerText && el.innerText.trim() === text) {
                          found = el;
                          break;
                      }
                  }
              } else {
                  found = elements[0];
              }

              if (found) {
                  clearInterval(check);
                  resolve(found);
              }
              
              if (Date.now() - start >= timeout) {
                  clearInterval(check);
                  reject(`Timeout waiting for selector: "${selector}"`);
              }
          }, 100); 
      });
  }

  // --- Stop Listener ---
  const stopListener = (msg) => {
      if (msg.action === "STOP_IMPORT") {
          console.log("PIEP: Stop command received.");
          isRunning = false;
      }
  };
  chrome.runtime.onMessage.addListener(stopListener);


  // --- Main Logic ---
  try {
      const data = await chrome.storage.local.get(['videoQueue']);
      let queue = data.videoQueue || [];

      if (queue.length === 0) {
          alert("PIEP: No URLs in queue!");
          window.piepImportRunning = false;
          return;
      }

      while (queue.length > 0 && isRunning) {
          const currentUrl = queue[0];
          chrome.runtime.sendMessage({ action: "UPDATE_STATUS", message: `Importing... (${queue.length} left)` });

          try {
              // --- STEP A: Click "Add sources" ---
              const addSourceLabel = await waitForElement(".mdc-button__label", "Add sources");
              addSourceLabel.closest('button').click();
              
              // --- STEP B: Click "YouTube" ---
              await delay(300); 
              const youtubeOption = await waitForElement("span", "YouTube");
              youtubeOption.click();

              // --- STEP C: Input URL ---
              await delay(300); 
              const inputField = await waitForElement('input[formcontrolname="newUrl"]');
              
              const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
              nativeInputValueSetter.call(inputField, currentUrl);
              
              inputField.dispatchEvent(new Event('input', { bubbles: true }));
              inputField.dispatchEvent(new Event('change', { bubbles: true }));
              
              // Validation Wait
              await delay(600); 
              if (!isRunning) throw "Stopped"; // Check before clicking insert

              // --- STEP D: Click "Insert" ---
              const insertBtnSpan = await waitForElement("span.mdc-button__label", "Insert");
              const insertBtn = insertBtnSpan.closest('button');

              if (insertBtn.disabled) await delay(1000);
              
              // Final check before commit
              if (!isRunning) throw "Stopped"; 
              insertBtn.click();

              // --- STEP E: Cooldown ---
              await delay(1200); 

              // --- STEP F: Update Queue ---
              queue.shift();
              await chrome.storage.local.set({ videoQueue: queue });

          } catch (error) {
              // --- ERROR HANDLING FIX ---
              if (error === "Stopped" || !isRunning) {
                  console.log("PIEP: Process stopped gracefully.");
                  break; // EXIT THE LOOP SILENTLY
              }

              console.error("PIEP Error:", error);
              const shouldContinue = confirm(`Error on: ${currentUrl}\n\nContinue?`);
              if (shouldContinue) {
                  queue.shift();
                  await chrome.storage.local.set({ videoQueue: queue });
              } else {
                  isRunning = false;
                  break;
              }
          }
      }

      if (queue.length === 0) {
          alert("PIEP: Done!");
          chrome.runtime.sendMessage({ action: "UPDATE_STATUS", message: "All Done!" });
      } else {
          chrome.runtime.sendMessage({ action: "UPDATE_STATUS", message: "Stopped." });
      }

  } catch (e) {
      console.error(e);
  } finally {
      // Cleanup: Release lock and remove listener
      window.piepImportRunning = false;
      chrome.runtime.onMessage.removeListener(stopListener);
  }

})();
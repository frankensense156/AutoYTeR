document.addEventListener('DOMContentLoaded', async () => {
    const btnScrape = document.getElementById('btn-scrape');
    const btnImport = document.getElementById('btn-import');
    const btnStop = document.getElementById('btn-stop');
    const statusDiv = document.getElementById('status');
    const ytControls = document.getElementById('yt-controls');
    const nbControls = document.getElementById('nb-controls');
  
    // 1. Check which tab is active
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // 2. Show correct controls based on URL
    if (tab.url.includes("notebooklm.google.com")) {
      ytControls.style.display = 'none';
      nbControls.style.display = 'block';
      
      // Check how many videos are waiting
      chrome.storage.local.get(['videoQueue'], (result) => {
        const count = result.videoQueue ? result.videoQueue.length : 0;
        statusDiv.innerText = `${count} URLs ready to import.`;
      });
    } else {
        statusDiv.innerText = "Go to a YouTube Playlist.";
    }
  
    // 3. Button Logic: Scrape (Runs PEEP.js)
    btnScrape.addEventListener('click', () => {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['PEEP.js']
      }, () => {
          // Callback after script runs
          statusDiv.innerText = "Scraping... check alerts.";
      });
    });
  
    // 4. Button Logic: Import (Runs URLXtractR.js)
    btnImport.addEventListener('click', () => {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['URLXtractR.js']
      });
      statusDiv.innerText = "Importing...";
      btnImport.style.display = 'none';
      btnStop.style.display = 'block';
    });
    
    // 5. Button Logic: Stop
    btnStop.addEventListener('click', () => {
       chrome.tabs.sendMessage(tab.id, { action: "STOP_IMPORT" });
       statusDiv.innerText = "Stopping...";
       btnImport.style.display = 'block';
       btnStop.style.display = 'none';
    });

    // Listen for updates from the scripts
    chrome.runtime.onMessage.addListener((request) => {
        if (request.action === "UPDATE_STATUS") {
            statusDiv.innerText = request.message;
        }
    });
});
(function() {
  console.log("PIEP: Scraping started...");
  const videoMap = new Map();

  // 1. Scrape the DOM for links
  document.querySelectorAll('a[href*="watch"]').forEach(a => {
    try {
      const url = new URL(a.href);
      const videoId = url.searchParams.get('v');
      const listId = url.searchParams.get('list');
      const index = url.searchParams.get('index');

      if (videoId && listId && index) {
        if (!videoMap.has(videoId)) {
          // Clean URL creation
          const cleanUrl = `https://www.youtube.com/watch?v=${videoId}`;
          videoMap.set(videoId, {
            url: cleanUrl,
            index: Number(index)
          });
        }
      }
    } catch (e) {}
  });

  // 2. Sort and Flatten
  const uniqueLinks = [...videoMap.values()]
    .sort((a, b) => a.index - b.index)
    .map(item => item.url);

  // 3. Save to Chrome Storage
  if (uniqueLinks.length > 0) {
    chrome.storage.local.set({ videoQueue: uniqueLinks }, () => {
      alert(`PIEP: Success! Saved ${uniqueLinks.length} videos. \n\nNow open NotebookLM and click 'Start Auto-Import'.`);
      chrome.runtime.sendMessage({ action: "UPDATE_STATUS", message: `${uniqueLinks.length} videos saved.` });
    });
  } else {
    alert("PIEP: No playlist videos found. Scroll to the bottom of the page to load all videos and try again.");
  }
})();